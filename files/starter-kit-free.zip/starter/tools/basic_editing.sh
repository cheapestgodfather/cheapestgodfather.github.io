# Basic editing: two functions (needs ffmpeg: https://ffmpeg.org)
# Usage: source tools/basic_editing.sh

# 1) Trim: keep from $2 to $3 seconds.  trim clip.mp4 1.5 6.5 clip_short.mp4
trim() { ffmpeg -v error -y -ss "$2" -to "$3" -i "$1" -c:v libx264 -crf 18 -c:a aac "$4"; }

# 2) Contact sheet: 8 frames from a clip.  board clip.mp4 sheet.jpg
board() { ffmpeg -v error -y -i "$1" -vf "fps=1/1.2,scale=480:-1,tile=4x2" -frames:v 1 -update 1 "$2"; }
