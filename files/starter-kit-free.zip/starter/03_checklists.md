# First-shot checklists

## Before you generate
- [ ] The **7 fields** are filled, in English (or "not applicable" written).
- [ ] The **duration** is the action plus about 1 second (you will trim).
- [ ] **One clear gesture** per shot (not a whole scene).
- [ ] You have a validated **start image**, with a single reference face if a character appears.
- [ ] You know **how much** you accept to spend on this shot.

## After generation (by eye, on the whole clip)
- [ ] **Face**: the same at the start, the middle and the end? (compare three still frames)
- [ ] **Hands**: five fingers, well placed? Nothing fused with an object?
- [ ] **Gaze**: nobody looks into the lens by mistake?
- [ ] **Speed**: gestures take their real-life time, no slow-motion or floating?
- [ ] **Sound**: voice, noises and ambience are right? Is the spoken text the one you wrote?
- [ ] **Stray details**: distorted letters, watermarks, an object from another era?

If a point fails: fix **one thing** in the prompt, rerun as a draft, and only go to final quality once the draft is good.

*By eye, these checks stay subjective. The complete method replaces them with measurements (face, voice) and written rules.*
