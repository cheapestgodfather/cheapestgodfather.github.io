# Prompt examples (copy from this file)

Every example follows the 7 fields. Adapt the subject, duration and light; keep the structure.

## 1. A complete example

```
[Duration] 5-second shot.
[Style] Photorealistic 1970s Italian arthouse cinematography, soft golden light, 35mm film grain, imperfect real skin, no beauty filter.
[Subject] Macro insert 85mm: an old man's weathered hand sets a small white espresso cup down on its saucer, on a white linen tablecloth; a thin curl of steam rises.
[Emotion] calm, unhurried.
[Camera] fixed macro, very shallow depth of field, a very slow push-in.
[Gestures] the hand lowers the cup, the fingers let go of the handle and rest beside the saucer.
[Weather/lighting] warm window light from the left, long soft shadows on the cloth.
[Audio] porcelain clicking on porcelain, a distant church bell, quiet room tone.
```

## 2. Shot 2: the terrace at dawn (calm wide shot)

```
[Duration] 8-second shot.
[Style] Photorealistic 1970s Italian arthouse cinematography, soft golden morning light, 35mm film grain.
[Subject] Wide establishing shot of an empty hilltop village terrace in Tuscany: a small round table with a white tablecloth, one espresso cup and a bottle of water, a rough stone wall behind. No people.
[Emotion] quiet, expectant.
[Camera] static wide 28mm, eye level, locked off.
[Gestures] a light breeze moves the edge of the tablecloth; a swallow crosses the frame once.
[Weather/lighting] low golden sun from the right, long soft shadows on the stone.
[Audio] a distant church bell, cicadas starting, quiet room tone.
```

## 3. A character who speaks

```
[Duration] 6-second shot, vertical 9:16.
[Style] Photorealistic 1970s Italian crime-film cinematography, warm low-key light, 35mm Kodak Vision3 500T grain, imperfect real skin, no beauty filter.
[Subject] Medium close-up: a 70-year-old man with a white moustache and a dark flat cap sits at a small marble cafe table in a Tuscan village square, looking slightly off-camera to the left.
[Emotion] amused, a little sly.
[Camera] locked 50mm, eye level, a very slow push-in on the last second.
[Gestures] he lifts a small espresso cup, takes a sip, sets it down, and says, in a low calm voice, in English: "Cheap is an art." Only his lips and one hand move; the head stays steady.
[Weather/lighting] late-afternoon sun from the right, soft shadows on his face.
[Audio] low raspy voice, cup on saucer, faint square ambience, no music.
```

## 4. A wide shot with a car

```
[Duration] 8-second shot.
[Style] Photorealistic 1970s Italian cinematography, soft natural light, 35mm film grain.
[Subject] Wide shot: a dark green vintage roadster pulls out of a stone courtyard through an arched gate and drives away to the right of the frame; nobody looks into the camera.
[Emotion] calm, unhurried.
[Camera] locked 35mm wide shot at hip height, no camera movement; the whole car stays visible.
[Gestures] the car rolls forward at normal speed, the brake lights flick once at the gate, it leaves the frame on the right; nothing else moves.
[Weather/lighting] soft overcast daylight, no harsh shadows.
[Audio] engine murmur, tyres on gravel, a distant dog, no music.
```

## 5. A rainy night insert

```
[Duration] 5-second shot.
[Style] Photorealistic 1970s Italian cinematography, cool blue night with warm practical lights, 35mm film grain.
[Subject] Insert 85mm: raindrops on the glass of a dark car window, a streetlamp blurred behind it.
[Emotion] tense, quiet.
[Camera] fixed, very shallow depth of field, a slow rack focus from the glass to the lamp.
[Gestures] not applicable; only the raindrops slide down the glass.
[Weather/lighting] light rain, one warm streetlamp in the background.
[Audio] rain on metal, distant thunder, quiet room tone, no music.
```

