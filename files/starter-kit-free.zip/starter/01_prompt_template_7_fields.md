# Prompt template — the 7 fields

A prompt = one **[Subject]** line + **7 decisions**. Write it **in English**; spoken dialogue can be in any language.
If a field does not apply (a still image has no audio), write "not applicable": it is a decision, not an omission.

## The template to copy
```
[Duration] ___-second shot.
[Style] (era), (film stock), (grain), imperfect real skin, no beauty filter.
[Subject] (who, where, what, in one sentence)
[Emotion] (inner state) + (what we see: eyes, mouth, breathing)
[Camera] (fixed / slow push-in / follow), (focal length), (start -> end)
[Gestures] (who moves what, in which direction); what stays still: (head, face)
[Weather/lighting] (time), (direction and colour of the light), (visible source)
[Audio] (ambience), (2 or 3 precise sound effects), (music: no)
```

## The 7 questions
| # | Field | The question |
|---|---|---|
| 1 | Duration | How many seconds does the action last? (generate a bit longer, you will trim) |
| 2 | Style | Which era, which film stock, which grain? |
| 3 | Emotion | What does the character feel, and what do we see of it? |
| 4 | Camera | How does it move? From which framing to which? |
| 5 | Gestures | Who does what, in which direction? What does not move? |
| 6 | Weather/lighting | What time is it? Where does the light come from? |
| 7 | Audio | Which ambience, which precise sounds? |

## A character who speaks?
Put the line in quotes inside **Gestures**, with the language and the tone, and keep it short (one sentence). Example: `says, in a low calm voice: "Want my guide?"`.
