# Shot sheet

One sheet per shot. It lets you reread yourself in six months, and redo a shot identically.

| | |
|---|---|
| **Shot** (name) | e.g. ep01_G1_garage_wide |
| **What happens** (one sentence) | |
| **Character(s)** and **place** | |
| **Start image** (file) | |
| **Who is on the left / right?** Direction of the car, of the gaze | |
| **Who looks at what?** (nobody looks into the lens) | |
| **Prompt** (paste the 7 fields) | |
| **Generated duration / kept duration** | / |
| **Tries** (no., what changed, result) | |
| **Decision** | selected / redo (what) / dropped |
| **Cost of the shot** | |
