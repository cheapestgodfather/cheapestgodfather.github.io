# Free starter kit — The Cheapest Godfather

Files to copy and paste while you follow **The Godfather's Guide** (the free 18-page guide). The first four need no installation: they are text templates.

## What is in this kit
| File | What it is for |
|---|---|
| `01_prompt_template_7_fields.md` | The blank 7-field template, to copy for every shot |
| `02_prompt_examples.md` | Complete prompts, ready to adapt (copy from this file, not from the PDF) |
| `03_checklists.md` | What to look at before you generate, then after |
| `04_shot_sheet.md` | A sheet to describe one shot and forget nothing |
| `journal/costs.csv` and `journal.md` | Your log: what each try cost, what you learned |
| `tools/basic_editing.sh` | Two editing functions: **trim** a clip and build a **contact sheet** |

## Your first shot in 6 moves
1. Copy `01_prompt_template_7_fields.md` into a new file and fill the 7 fields **in English**.
2. Generate a **start image** first and keep only one (guide, chapter "The start image").
3. Animate it as a **draft** with the same prompt; review the clip with `03_checklists.md` ("After" part).
4. Fix **one thing at a time**, rerun, and only when the draft is good switch to final quality.
5. Trim the good part: `source tools/basic_editing.sh` then `trim clip.mp4 1 5 clip_short.mp4` (needs `ffmpeg`).
6. Write the cost in `journal/costs.csv`.

## What this kit does not do
It does not **measure** anything and does not **remember** anything: by eye, a drifting face still looks fine for one shot, then not by the third. The rest of the method is the **complete manual** and its **complete kit**: a registry that keeps characters and places consistent, rules that attach themselves to every prompt, a measured face audit, a voice check and film assembly. Details: https://cheapestgodfather.github.io/en/

All characters and places in the examples are fictional and AI-generated.
