# Studio journal

## Date — shot — what I tried
- What I changed in the prompt:
- Result:
- What I learned (a rule to reuse):
