# Modèle de prompt — les 7 champs

Un prompt = une ligne **[Subject]** + **7 décisions**. Écris-le **en anglais** ; les dialogues peuvent rester en français.
Si un champ ne s'applique pas (une image fixe n'a pas d'audio), écris « not applicable » : c'est une décision, pas un oubli.

## Le modèle à copier
```
[Duration] ___-second shot.
[Style] (époque), (pellicule), (grain), imperfect real skin, no beauty filter.
[Subject] (qui, où, quoi, en une phrase)
[Emotion] (état intérieur) + (ce qu'on voit : regard, bouche, respiration)
[Camera] (fixe / push-in lent / suivi), (focale), (départ -> arrivée)
[Gestures] (qui bouge quoi, dans quel sens) ; ce qui reste immobile : (tête, visage)
[Weather/lighting] (heure), (direction et couleur de la lumière), (source visible)
[Audio] (ambiance), (2 ou 3 bruitages précis), (musique : non)
```

## Les 7 questions
| # | Champ | La question |
|---|---|---|
| 1 | Duration | Combien de secondes dure l'action ? (génère un peu plus long, tu couperas) |
| 2 | Style | Quelle époque, quelle pellicule, quel grain ? |
| 3 | Emotion | Que ressent le personnage, et que voit-on de cette émotion ? |
| 4 | Camera | Comment bouge-t-elle ? De quel cadre à quel cadre ? |
| 5 | Gestures | Qui fait quoi, dans quel sens ? Qu'est-ce qui ne bouge pas ? |
| 6 | Weather/lighting | Quelle heure ? D'où vient la lumière ? |
| 7 | Audio | Quelle ambiance, quels bruits précis ? |

## Un personnage qui parle ?
Écris sa réplique entre guillemets dans **Gestures**, avec la langue et le ton, et garde-la courte (une phrase). Exemple : `says, in a low calm voice, in French: « Tu veux mon guide ? »`.
