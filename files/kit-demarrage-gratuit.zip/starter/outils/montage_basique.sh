# Montage de base — deux fonctions (nécessite ffmpeg : https://ffmpeg.org)
# Utilisation : source outils/montage_basique.sh

# 1) Rogner : garder de $2 à $3 secondes.  rogner clip.mp4 1.5 6.5 clip_court.mp4
rogner() { ffmpeg -v error -y -ss "$2" -to "$3" -i "$1" -c:v libx264 -crf 18 -c:a aac "$4"; }

# 2) Planche de contrôle : 8 images d'un clip.  planche clip.mp4 planche.jpg
planche() { ffmpeg -v error -y -i "$1" -vf "fps=1/1.2,scale=480:-1,tile=4x2" -frames:v 1 -update 1 "$2"; }
