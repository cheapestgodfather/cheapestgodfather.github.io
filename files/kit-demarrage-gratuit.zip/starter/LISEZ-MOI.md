# Kit de démarrage gratuit — The Cheapest Godfather

Les fichiers à copier-coller pour appliquer **Le Guide du Parrain** (le guide gratuit de 18 pages). Tu n'as rien à installer pour les quatre premiers : ce sont des modèles de texte.

## Ce que contient ce kit
| Fichier | Pour quoi faire |
|---|---|
| `01_modele_prompt_7_champs.md` | Le modèle vierge des 7 champs, à copier pour chaque plan |
| `02_exemples_de_prompts.md` | Des prompts complets, prêts à adapter (copie depuis ce fichier, pas depuis le PDF) |
| `03_checklists.md` | Ce qu'il faut regarder avant de générer, puis après |
| `04_fiche_de_plan.md` | Une fiche pour décrire un plan, et ne rien oublier |
| `journal/couts.csv` et `journal.md` | Ton journal : ce que chaque essai t'a coûté, ce que tu as appris |
| `outils/montage_basique.sh` | Deux fonctions de montage : **rogner** un clip et fabriquer une **planche de contrôle** |

## Ton premier plan en 6 gestes
1. Copie `01_modele_prompt_7_champs.md` dans un nouveau fichier ; remplis les 7 champs **en anglais**.
2. Génère d'abord une **image de départ**, garde-en une seule (guide, chapitre « L'image de départ »).
3. Anime-la en **brouillon** avec le même prompt ; regarde le clip avec `03_checklists.md` (partie « Après »).
4. Corrige **une seule chose à la fois**, relance, puis seulement quand c'est bon passe en qualité finale.
5. Rogne le bon passage : `source outils/montage_basique.sh` puis `rogner clip.mp4 1 5 clip_court.mp4` (il faut `ffmpeg`).
6. Note le coût dans `journal/couts.csv`.

## Ce que ce kit ne fait pas
Il ne **mesure** rien et ne **mémorise** rien : à l'œil, un visage qui dérive paraît encore bon pendant un plan, puis plus au troisième. La suite de la méthode, c'est le **manuel complet** et son **kit complet** : un registre qui garde les personnages et les décors cohérents, des règles qui s'ajoutent toutes seules à chaque prompt, un audit chiffré du visage, la vérification de la voix et l'assemblage du film. Détails : https://cheapestgodfather.github.io/fr/

Tous les personnages et lieux des exemples sont fictifs et générés par IA.
