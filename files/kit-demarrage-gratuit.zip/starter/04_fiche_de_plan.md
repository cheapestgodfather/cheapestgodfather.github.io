# Fiche de plan

Une fiche par plan. Elle te sert à te relire dans six mois, et à refaire un plan à l'identique.

| | |
|---|---|
| **Plan** (nom) | ex. ep01_G1_garage_large |
| **Ce qui se passe** (une phrase) | |
| **Personnage(s)** et **lieu** | |
| **Image de départ** (fichier) | |
| **Qui est à gauche / à droite ?** Sens de la voiture, du regard | |
| **Qui regarde quoi ?** (personne ne regarde l'objectif) | |
| **Prompt** (colle les 7 champs) | |
| **Durée générée / durée gardée** | / |
| **Essais** (n°, ce qui a changé, résultat) | |
| **Décision** | retenu / à refaire (quoi) / jeté |
| **Coût du plan** | |
