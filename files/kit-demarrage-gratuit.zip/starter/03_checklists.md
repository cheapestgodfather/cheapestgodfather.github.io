# Check-lists du premier plan

## Avant de générer
- [ ] Les **7 champs** sont remplis, et en anglais (ou « not applicable » écrit).
- [ ] La **durée** est celle de l'action plus environ 1 seconde (tu couperas).
- [ ] Un **seul geste net** par plan (pas une scène entière).
- [ ] Tu as une **image de départ** validée, avec un seul visage de référence si un personnage apparaît.
- [ ] Tu sais **combien** tu acceptes de dépenser sur ce plan.

## Après la génération (à l'œil, sur le clip entier)
- [ ] **Visage** : le même au début, au milieu et à la fin ? (compare trois images arrêtées)
- [ ] **Mains** : cinq doigts, bien placées ? Rien de fondu avec un objet ?
- [ ] **Regard** : personne ne regarde l'objectif par erreur ?
- [ ] **Vitesse** : les gestes ont leur durée réelle, sans effet ralenti ni flottant ?
- [ ] **Son** : voix, bruits et ambiance sont corrects ? Le texte dit est bien celui que tu avais écrit ?
- [ ] **Détails parasites** : lettres déformées, filigranes, objet d'une autre époque ?

Si un point échoue : corrige **une seule chose** dans le prompt, relance en brouillon, ne repasse en qualité finale qu'une fois le brouillon bon.

*À l'œil, ces contrôles restent subjectifs. La méthode complète les remplace par des mesures (visage, voix) et des règles écrites.*
