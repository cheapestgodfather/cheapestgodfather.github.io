# Journal du studio

## Date — plan — ce que j'ai essayé
- Ce que j'ai changé dans le prompt :
- Résultat :
- Ce que j'ai appris (une règle à réutiliser) :
